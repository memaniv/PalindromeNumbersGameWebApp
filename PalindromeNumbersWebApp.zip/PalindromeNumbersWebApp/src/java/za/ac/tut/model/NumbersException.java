package za.ac.tut.model;

/**
 *
 * @author MemaniV
 */
public class NumbersException extends RuntimeException {
    public NumbersException(String errMsg){
        super(errMsg);
    }
    
}


