package za.ac.tut.model;

/**
 *
 * @author MemaniV
 */
public interface NumbersCheckerInterface {
    public boolean isNumberValid(int number) throws NumbersException;
    public boolean isNumberPalindrome(int number);
}

